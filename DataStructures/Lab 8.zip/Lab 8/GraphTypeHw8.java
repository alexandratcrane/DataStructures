
/**
 * Write a description of class GraphTypeHw8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class GraphTypeHw8<E>
{
    // instance variables - replace the example below with your own
    int numVertex;
    int numEdge;
    HashMap<E, ArrayList<E>> graph;
    
    public GraphTypeHw8(){
        //numVertex = n;
        graph = new HashMap<>(); //leave empty cuz we dont know E data type values yet 
        numEdge = 0;
        numVertex = 0;
    }
    public void addVertex(E u){  //helps u cr8 linked ArrayList
        //if(!graph.containsKey(u)){
        ArrayList al = new ArrayList<E>();
        graph.put(u, al);
        numVertex++;
    }
    public ArrayList<E> getEdges(E u){
        return graph.get(u);
    }
    public boolean edgePresent(E u, E v){
        return(graph.get(u).contains(v));
    }
    public void addEdge(E u, E v){
        
        if(!edgePresent(u,v)){ //checks if arraylist/key u exists
            graph.get(u).add(v);
            numEdge++;
        }    
        
        if(!edgePresent(v,u)){
            graph.get(v).add(u);
            numEdge++;
        }    
            /* old way of coding w/out addvertex method
            ArrayList<E> p = new ArrayList<E>(); //makes new AL to attach to u
            p.add(v); //add v to p AL
            graph.put(u,p); //attached p to key u
            */
        
        }    
        
        /*   HW for Lab 8 
         * for every movie u want to attach cast members for that movie
         * 
         */
    /*public static void main(String[] args){
        GraphTypeHw8<String> gt = new GraphTypeHw8<>(5);
        gt.addEdge("deer", "dog");
        gt.addEdge("deer", "cat");
        gt.addEdge("cat", "dog");
        gt.addEdge("tiger", "lion");
    } 
    */
    }
    

    

