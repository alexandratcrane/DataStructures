
/**
 * Write a description of class MovieGraph here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
public class MovieGraph extends GraphType
{
    //graph type is string. movies and cast listed as String
    
    GraphType<String> movieGraph;
    HashSet<String> cast;
    HashSet<String> movies;
    String fileName = "movies.txt";
    //fileName = "movie.txt";
    
    public MovieGraph(){
        movieGraph = new GraphType<>();
        cast = new HashSet<>();
        movies = new HashSet<>();
    }
    
    public void numMovies(){
        System.out.println("Number of movies " + movies.size());
    }
    public void numCast(){
        System.out.println("Number of cast " + cast.size());
    }
    
    public void movieList(String cm){
        System.out.println(movieGraph.graph.get(cm)); //gets arraylist and prints it
    }
    
    public ArrayList<String> commonMovies (ArrayList<String> al1, ArrayList<String> al2){
        ArrayList<String> common = new ArrayList<>();
        for(String s: al1){
            if(al2.contains(s)){
                common.add(s);
            }
        }
        return common;
    }
    
    public void coCast(int minMovies){
        ArrayList<String> castMin = new ArrayList<>();
        for(String s: cast){
            if(movieGraph.graph.get(s).size() >= minMovies){
                castMin.add(s); //now contains all actors that have acted in minmovie
            }
        }
        
        for(String p: castMin){
            for(String q: castMin){
                if(p.compareTo(q) < 0){
                    ArrayList<String> al = commonMovies(movieGraph.graph.get(p), movieGraph.graph.get(q));
                    //intersect arraylist of movies featureing p and q
                    if (al.size() >= minMovies){
                        System.out.println("the cast members are: " + p + ", " + q);
                        System.out.println(al);
                        System.out.println();
                    }
                }
            }
        }
        
     
    }
    public static void main(String[] args){
        MovieGraph mg = new MovieGraph();
        mg.readMovieInfo();
        //mg.movieList("Cruise, Tom");
        mg.coCast(13);
    }
    
    public void readMovieInfo(){  //read file and build graph
        Scanner fileScanner;
        String line;
        try{
            fileScanner = new Scanner(new File(fileName));
            while(fileScanner.hasNext()){
                line = fileScanner.nextLine();
                //split each line with /
                //two hashsets
                String[] movieInfo = line.split("/");
                String movieName = movieInfo[0];
                movies.add(movieName);
                movieGraph.addVertex(movieName);
                
                for(int i=1; i <  movieInfo.length; i++){
                    String cm = movieInfo[i];
                    //cast.add(cm);  //makes sure cast members not repeated
                    if(!cast.contains(cm)){
                        movieGraph.addVertex(cm);
                        cast.add(cm);  //every cast member is unique
                        
                    }
                    movieGraph.addEdge(cm, movieName);
                }
                
            }
         
        }
        catch(IOException e){
            System.out.println(e);
            
        }
    }
}
