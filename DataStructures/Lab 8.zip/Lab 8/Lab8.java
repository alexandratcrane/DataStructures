
/**
 * Write a description of class Lab8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;
public class Lab8<E>
{
    // instance variables - replace the example below with your own
    int numVertex;
    int numEdge;
    Scanner fileScanner;
    HashMap<E, ArrayList<E>> graph;
    
    public Lab8(){
        //numVertex = n;
         
        graph = new HashMap<>(); //leave empty cuz we dont know E data type values yet 
        numEdge = 0;
        String word = null;
        int slash = 0;
        try{
        fileScanner = new Scanner(new File ("movies.txt"));
        
        while(fileScanner.hasNext()){
            word = fileScanner.next();
            slash = word.indexOf('/');
            
        }
            
        }//try
        catch(IOException e){
            System.out.println(e);
        }
    }
    public void addVertex(E u){  //helps u cr8 linked ArrayList
        if(!graph.containsKey(u)){
            graph.put(u, new ArrayList<E>());
        }
        else{
            System.out.println("vertex already present...");
            
        }
    }
    public void addEdge(E u, E v){
        /* first c8 an entry in hashmap with u in it as the key and an empty arraylist attached
         * then add v to it
         * do it the other way around 
         */
        if(graph.containsKey(u)){ //checks if arraylist/key u exists
            graph.get(u).add(v); // gets arraylist attached to key u and then adds to AL
        }    
        else{
            addVertex(u);
            graph.get(u).add(v);    
                
        }
        if(graph.containsKey(v)){
            graph.get(v).add(u);
        }    
        else{
            addVertex(v);
            graph.get(u).add(v);
        }
            /* old way of coding w/out addvertex method
            ArrayList<E> p = new ArrayList<E>(); //makes new AL to attach to u
            p.add(v); //add v to p AL
            graph.put(u,p); //attached p to key u
            */
        numEdge++;
        }    
        
        /*   HW for Lab 8 
         * for every movie u want to attach cast members for that movie
         * 
         */
    public static void main(String[] args){
        
        Lab8<String> gt = new Lab8<>();
        gt.addEdge("deer", "dog");
        gt.addEdge("deer", "cat");
        gt.addEdge("cat", "dog");
        gt.addEdge("tiger", "lion");
    } 
    }
    

    

