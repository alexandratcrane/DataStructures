
/**
 * Write a description of class ALinAL here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * Graph Class
 * arraylist of arraylists used to represent a graph
 * addEdge will create a connection between vertices i and j
 * 
 * this is costly to check in both time and size
 * esp when going thru duplicates. avoid duplicates using hashset 
 * can make ArrayList<HashSet<Integer>> graph 
 * the lookup in hashset will have o(1) lookup making time complexity shorter 
 * buuut hashset will take up more space 
 * 
 * 
 */
import java.util.*;
public class Graph
{
    // instance variables - replace the example below with your own
    int numVertex;
    int numEdges;
    ArrayList<ArrayList<Integer>> graph;
    
    public Graph(int n){
        graph = new ArrayList<ArrayList<Integer>>(n);
        //n adjacency lists that will be connected to verticalList
        for(int i=0; i<n; i++){  //this attaches adjacency lists to verticalList
            graph.add(new ArrayList<Integer>());
        }
        numEdges = 0;
        numVertex = n;
        
    }
    public int degree(int v){
        return (graph.get(v).size());
    }
    
    public boolean ifEdgePresent(int u, int v){
        return(graph.get(u).contains(v));
        //if u contains v, then .get(v) does contain u 
    }
    
    public void deleteEdge(int u, int v){
        if (ifEdgePresent(u,v)){  
            graph.get(u).remove(v);
            graph.get(v).remove(u);
            numEdges --;
        }
        else{
            System.out.println("edge " + u + "," + v + " not present");
        }

    }
    
    public void addEdge(int i, int j){
        //add j to adj list for i 
        ArrayList<Integer> p = graph.get(i);  // gets the adjacency list to vertex i
        if(!p.contains(j)){  //makes sure to not add same adjacency twice 
            p.add(j);
        }//adds j to adjacency list to vertex i
        
        //now we add i to j's adj list
        ArrayList<Integer> q = graph.get(j);
        if(!q.contains(i)){
            q.add(i);
        }
     
        
        /* you can actually do this code in one line
         * if(!graph.get(i).contains(j)) graph.get(i).add(i);
         */
        numEdges++;
    }
    
    public static void main(String [] args){
        Graph g = new Graph(5);
        g.addEdge(0,1);
        g.addEdge(4,0);
        g.addEdge(1,2);
        g.addEdge(2,3);
        g.addEdge(3,4);
        g.addEdge(1,3);
        g.addEdge(1,4);
        
    }
}
