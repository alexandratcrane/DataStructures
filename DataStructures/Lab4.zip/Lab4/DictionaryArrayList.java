import java.util.*;
import java.io.*;

public class DictionaryArrayList{
    ArrayList<String> words = new ArrayList<>();
    int duplicates = 0;
    
    public void fileRead(){
        Scanner reader = null;
        try{
            reader = new Scanner(new File("EnglishWordList.txt"));
            
        }
        catch(FileNotFoundException ex){
            System.out.println(ex + "file not found");
        }
        while(reader.hasNext()){
            String str = reader.nextLine();
            if(!words.contains(str)){
            words.add(str);
        }
        else{
            duplicates++;
        }
        }
    }//readfile
    
    public static void main(String[] args){
        long t1 = System.currentTimeMillis();
        DictionaryArrayList t = new DictionaryArrayList();
        t.fileRead();
        System.out.println("Amount of words: " + t.words.size());
        System.out.println("Duplicates: " + t.duplicates);
        long t2 = System.currentTimeMillis();
        long time = t2 - t1;
        
        System.out.println("Time: " + (time/1000));
        
        
    }//main
    // instance variables - replace the example below with your own
    }
