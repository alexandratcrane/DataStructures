
/**
 * arg for linkedlist: known head and tail
 * can use addLast method still 
 * head and tail can be reveresed 
 */
import java.util.*;

public class Queue<E> extends LinkedList<E>
{
    //decide if u want array or linkedlist
    //add at the tail of the queue
    //make dequeue extend queue??
    
    //first is tail
    public void enqueue(E e){
        addFirst(e);
    }
    
    
    //detele at the head of the queue and return deleted value
    //last is head
    public E dequeue(){
        if(!isEmpty()){
        return removeLast();
    }
    else{
        System.out.println("queue is empty....");
        return null;
    }//ELSE
    } // dequeue
}
