
/**
 * Write a description of class Homework10 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.*;

public class Homework10{

    public static void main(String[] args){
        HashSet<String> dictSet = new HashSet<>();
        // ArrayList<String> autoList = new ArrayList<>();
        HashMap<String, Integer> autoMap = new HashMap<>();
        HashSet<String> stopSet = new HashSet<>();

        Scanner dictScanner;
        Scanner autoScanner;
        Scanner stopScanner;
        String autoFile = "Automotive_5.txt";
        String stopFile = "stop_words.txt";
        String dictFile = "EnglishWordList.txt";

        //reading words for stopFile 
        try {
            stopScanner = new Scanner (new File (stopFile));
            while (stopScanner.hasNext()) {
                String word = stopScanner.next();
                word = word.replaceAll("[\\[\\]_:\"'`?;\\�0-9�;�()-/.,*! ]", "").toLowerCase();
                //System.out.println(word);
                stopSet.add(word);
            }
            stopSet.add(" ");
        } catch (IOException e) {
            System.out.println(e);
        }

        //reading words for dictFile
        try {
            dictScanner = new Scanner (new File (dictFile));
            while (dictScanner.hasNext()) {
                String word = dictScanner.next();
                word = word.replaceAll("//s+", "").toLowerCase();  //idk why but it gets the code to work
                //System.out.println(word);

                dictSet.add(word);

            }
        } catch (IOException e) {
            System.out.println(e);
        }     
        try {
            autoScanner = new Scanner (new File (autoFile));
            while (autoScanner.hasNext()) {
                String word = autoScanner.next();
                word = word.replaceAll("[\\[\\]_:\"'`?;\\�0-9�;�()-/.,*!\\s ]", "").toLowerCase();
                //word = word.replaceAll("\\s+", "").toLowerCase();
                //System.out.println(word);
                if((!stopSet.contains(word)) && (dictSet.contains(word))){ //O(1)
                    if(autoMap.containsKey(word)){
                        Integer i = autoMap.get(word);
                        //System.out.println(word);
                        autoMap.put(word, 1+i);
                    }
                    else{
                        autoMap.put(word, 1);
                    }//else
                }//if

            }
        } catch (IOException e) {
            System.out.println(e);
        }  
        ArrayList<String> list = new ArrayList<String>(autoMap.keySet()); 
        Collections.sort(list, new Comparator<String>() {
                public int compare(String x, String y) {
                    return autoMap.get(y) - autoMap.get(x);
                }
            });

        ArrayList<String> firstFive = new ArrayList();
        ArrayList<String> lastFive = new ArrayList();

        for (int i = 0; i < 5; i++) {
            firstFive.add(list.get(i));
        }

        for (int i = list.size() - 5; i < list.size(); i++) {
            lastFive.add(list.get(i));
        }

        //print results
        System.out.println("These words were counted the most");
        for(String str: firstFive){
            System.out.println("The word " + str + " was counted " + autoMap.get(str) + " times");
        }
        System.out.println("");
        System.out.println("These words were counted the least");
        for(String str: lastFive){
            System.out.println("The word " + str + " was counted " + autoMap.get(str) + " times");
        }
    }//main
}