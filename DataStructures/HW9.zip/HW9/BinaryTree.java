
public class BinaryTree<E>
{
    Node<E> root;
    int numNodes;
    
    public BinaryTree(E val)
    {
        root = new Node(null,null,null,val);
        numNodes=1;
    }
    
    public void setLeftBT(Node<E> p, Node<E> c) {
        
        p.setLeft(c);
        c.setParent(p);
        numNodes++;
    }
    
    public void setRightBT(Node<E> p, Node<E> c) {
        
        p.setRight(c);
        c.setParent(p);
        numNodes++;
    }
    
    public static void main(String[] args){
        //preorder  E F B C D G H A 
        //postorder  F H G D C A B E 
        //inorder F E G H D C B A
      
        BinaryTree<Character> tree = new BinaryTree('E');
        Node<Character> na = new Node(null, null, null, 'A'); 
        Node<Character> nb = new Node(null, null, null, 'B');
        Node<Character> nc = new Node(null, null, null, 'C');
        Node<Character> nd = new Node(null, null, null, 'D'); 
     
        Node<Character> nf = new Node(null, null, null, 'F'); 
        Node<Character> ng = new Node(null, null, null, 'G');
        Node<Character> nh = new Node(null, null, null, 'H');
        
        tree.setLeftBT(tree.root, nf);
        tree.setRightBT(tree.root, nb);
        
        tree.setLeftBT(nb, nc);
        tree.setRightBT(nb, na);
        
        tree.setLeftBT(nc, nd);
        tree.setLeftBT(nd, ng);
        tree.setRightBT(ng, nh);
        
        tree.preOrder(tree.root);
        System.out.println();
        tree.postOrder(tree.root);
        System.out.println();
        tree.inOrder(tree.root);
        /*
        BinaryTree<String> bt = new BinaryTree("cat");
         //bt.root = new Node("cat");
         Node<String> n1 = new Node(null,null,null,"dog");
         Node<String> n2 = new Node(null,null,null,"rabbit");
         // make n1 left child of the root
         bt.setLeftBT(bt.root, n1);
         // make n2 right child of the root
         bt.setRightBT(bt.root,n2);
           Node<String> n3 = new Node(null,null,null,"mouse");
         Node<String> n4 = new Node<>(null,null,null,"hamster");
           bt.setLeftBT(n1,n3);
           bt.setRightBT(n2,n4);
           
           bt.postOrder(bt.root);
           System.out.println();
           bt.preOrder(bt.root);
        */
    }
    
    public void preOrder(Node<E> t){
         if (t==null) return;  
        System.out.println(t.getInfo());
        preOrder (t.getLeft());
        preOrder(t.getRight());
    }
    
    public void postOrder(Node<E> t) {
           if (t==null) return;
        postOrder (t.getLeft());
        postOrder(t.getRight());
        System.out.println(t.getInfo());
    }
    
    public void inOrder(Node<E> t) {
        
        if (t==null) return;
        inOrder (t.getLeft());
        System.out.println(t.getInfo());
        inOrder(t.getRight());
    }
    
    public boolean isLeaf(Node<E> p){
        if(p.getLeft() == null && p.getRight() == null){
            return true;
        }
        return false;
    }
    
    public boolean isRoot(Node<E> p){
        if(p.getParent() == null){
            return true;
        }
        return false;
    }
    
    public boolean deleteLeaf (Node<E> p){
        if(isLeaf(p) == true){
            p.setParent(null);
            p.setValue(null);
            return true;
        }
        return false;
    }
}
