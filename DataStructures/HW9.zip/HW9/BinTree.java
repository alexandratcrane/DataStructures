

public class BinTree<E>
{
    
    Node<E> root;
    int size;
    
    public BinTree()
    {
        root=null;
        size=0;
    }
    
    public BinTree(E val) {
        root = new Node(null, null, null,val);
        size=1;
    }
    
    public void addLeft(Node<E> p, Node<E> child) {
        /*
        child.parent=p;
        p.left=child;
        size++;
        */
        
       child.setParent(p);
       p.setLeft(child);
       size++;
       
    }
    
     public void addRight(Node<E> p, Node<E> child) {
         
          child.setParent(p);
       p.setRight(child);
       size++;
         
        }
        
        public static void main(String[] args) {
            
            BinTree<Integer> tree= new BinTree<>(0);
            
            Node<Integer> n1 = new Node<>(null,null,null,1);
            tree.addLeft(tree.root,n1);
             Node<Integer> n2 = new Node<>(null,null,null,2);
             tree.addRight(tree.root,n2);
              Node<Integer> n3 = new Node<>(null,null,null,3);
              tree.addLeft(n2,n3);
               Node<Integer> n4 = new Node<>(null,null,null,4);
               tree.addRight(n2,n4);
                Node<Integer> n5 = new Node<>(null,null,null,5);
                tree.addRight(n4,n5);
        }

    
}
